package com.example.gm_cc.snacky2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SecondActivity extends AppCompatActivity {
    private Button lugardemax;
    private Button subway;
    private Button jixiang;
    private Button cafesmothies;
    private Button benditacafeina;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        lugardemax=(Button) findViewById(R.id.btnLugardeMax);
        subway=(Button) findViewById(R.id.btnSubway);
        jixiang=(Button) findViewById(R.id.btnJiXiang);
        cafesmothies=(Button) findViewById(R.id.btnCafeySmothies);
        benditacafeina=(Button) findViewById(R.id.btnBenditaCafeina);
    }
    public void lugar(View vista){
        Intent intent = new Intent(SecondActivity.this, TirtActivity.class);
        startActivity(intent);
    }
    public void subway(View vista){
        Intent intent = new Intent(SecondActivity.this, fortActivity.class);
        startActivity(intent);
    }
    public void jixiang(View vista){
        Intent intent = new Intent(SecondActivity.this, fiveActivity.class);
        startActivity(intent);
    }
    public void cafesmo(View vista){
        Intent intent = new Intent(SecondActivity.this, sixActivity.class);
        startActivity(intent);
    }
    public void bcafe(View vista){
        Intent intent = new Intent(SecondActivity.this, sevActivity.class);
        startActivity(intent);
    }
}

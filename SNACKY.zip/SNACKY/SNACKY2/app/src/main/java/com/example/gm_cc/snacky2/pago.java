package com.example.gm_cc.snacky2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;

public class pago extends AppCompatActivity {
    private Button button;
    private ImageButton imageButton;
    private RadioButton radioButton;
    private RadioButton radioButton2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pago);
        button = (Button) findViewById(R.id.button);
        imageButton = (ImageButton) findViewById(R.id.imageButton);
        radioButton =(RadioButton) findViewById(R.id.radioButton);
        radioButton2=(RadioButton) findViewById(R.id.radioButton2);
    }
    public void button(View vista){
        Intent intent = new Intent(pago.this, orden.class);
        startActivity(intent);
    }
}
